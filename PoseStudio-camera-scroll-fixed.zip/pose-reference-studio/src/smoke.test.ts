import { describe, expect, it } from "vitest";

describe("Pose Studio project smoke checks", () => {
  it("has a valid category inventory size", () => {
    const categories = ["Street","Cafe","Rooftop","Beach","Studio","Nature","Urban","Architecture","Park","Travel","Lifestyle","Fashion","Seated","Standing","Walking","Portrait","Couples","Friends","Golden Hour","Night","Minimal","Creative"];
    expect(categories).toHaveLength(22);
  });
  it("keeps overlay opacity in the supported range", () => {
    const clamp = (n:number) => Math.max(0, Math.min(100, n));
    expect(clamp(-2)).toBe(0);
    expect(clamp(45)).toBe(45);
    expect(clamp(120)).toBe(100);
  });
});